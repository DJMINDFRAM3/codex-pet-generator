---
name: images-video
description: Create and edit images and generate short videos through the model gateway. Use when the user wants a picture, logo, diagram, mockup, an edit to an image they have, a short video clip, or a video built from a photo or an existing clip.
---

## Images and video

The helpers live in `/workspace/ninja/utils/`. They find the gateway and its
credentials themselves — nothing to configure. Run everything from
`/workspace/ninja`.

For speech, sound effects and transcription, use the audio skill instead.

### Create an image from text

```bash
python -m utils.images generate -o logo.png \
  "A flat minimal logo of a paper plane, single colour, plain background"
```

| Option | Values |
|---|---|
| `--size` | `1024x1024` (default), `1024x1536` portrait, `1536x1024` landscape, `2048x2048`, `auto` |
| `--quality` | `low`, `medium`, `high` — use `high` for text, charts, fine detail |
| `--model` | `gpt-image` (default), `gemini-image` (alternative provider) |

From Python: `from utils.images import generate_image`.

### Edit or combine images

Takes up to 16 reference images. Number them in the prompt ("Image 1", "Image
2", …) and say what must stay the same, or the model will drift.

```bash
python -m utils.images edit --ref chair.png --ref cat.png -o cat_on_chair.png \
  "Image 1 is a wooden chair. Image 2 is a tabby cat. Put the cat on the chair. Keep the chair's design and the cat's markings unchanged."
```

`--ref-dir ./refs/` uses every image in a folder, in alphabetical order. Use this
for style transfer, compositing, swapping text or colours, and localising an
existing design.

From Python: `from utils.images import edit_image`.

### Create a video from text, an image, or another clip

Slow — minutes, not seconds — so it is three steps, not one call. Do them in
order.

**1. Start it, and tell the user.** Keep the id you get back — it is the whole
handoff if this run ends before the clip does, and **handing off** below says
what the issue must contain.

```bash
python -c "
from utils.video import submit_video
print(submit_video('A red balloon drifting over a green field, cinematic', seconds=5))
"
```

**You write the prompt, so watch what goes into it.** The provider moderates
the finished render rather than the request, so a refusal lands minutes later
with the full charge already made — one 20-second clip was flagged after five
minutes and forty seconds, billed at $9.32. What gets refused:

- **a real company's logo, wordmark or product name** — the one we have actually
  had refused, on a frame carrying the Slack mark that the prompt asked for by name
- real or identifiable people, public figures, copyrighted characters
- violence, weapons, injury; sexual or suggestive content; minors near either
- drugs, self-harm, political figures and symbols

Describe things generically instead — "a chat app's message bubble", not the
brand. If what they asked for genuinely needs one of these, say so before
spending, and prove the idea at four seconds ($1.86) before paying for twenty.

`seconds` is **4 to 30**. Every second is charged, and the render takes minutes:

| length | charged | measured render time |
|---|---|---|
| 4-5 seconds | $1.86 - $2.33 | 3 to 8 minutes |
| 20 seconds | $9.32 | 4 to 8 minutes |
| 28-30 seconds | $13.05 - $13.98 | 10 to 12 minutes |

So **ask how long they want it** unless they said, and don't reach for 30
seconds when 5 will do.

**Tell the user the slow end of that range, not the fast end.** Below twenty
seconds the wait barely tracks the length at all — a five-second clip has taken
eight minutes — so any tidier number you quote is a number you will be asked
about. Say "up to eight minutes" and deliver in four. A long wait is not a
failure; a wait longer than the one you promised reads like one.

**`queued` means it has not started yet**, and those are render times measured
from the moment it does. A job can wait in the provider's queue first — one
27 MB upload sat there eleven minutes before rendering at all. So a `queued`
status is not a stall, and it is never a reason to submit again: that clip is
paid for and a fresh submit buys a different one. If it is still queued after
a few minutes, say so in the thread rather than letting your estimate quietly
expire.

**If the user gave you a file — an image to pin, a clip to reference, anything
you might need to trim or resize — install ffmpeg before you start:**

```bash
apt-get update -qq && apt-get install -y -qq ffmpeg    # about 30 seconds
```

It is not in the sandbox. Half a minute up front beats discovering halfway in
that you cannot check a clip's length or cut it down.

**A file travels inside the request, so it is size-limited: 5 MB an image,
10 MB a clip, 20 MB across one request.** Anything bigger is refused before it
is sent — free, but it costs you a turn, so compress once up front:

```bash
ffmpeg -v error -i theirs.mp4 -c:v libx264 -crf 28 -preset veryfast -an ref.mp4 -y
ffmpeg -v error -i theirs.png -vf scale=-2:1080 -q:v 3 ref.jpg -y
```

A public URL is never measured — the model fetches those itself.

**Giving it something to work from.** Two modes, and they cannot be combined —
the model refuses a request that mixes them.

*Pin the timeline* — the clip opens, or opens and closes, on your images:

```bash
python -c "
from utils.video import submit_video
print(submit_video('the camera slowly pushes in', seconds=5,
                   first_frame='photo.jpg', last_frame='photo2.jpg'))
"
```

*Guide the whole clip* — keep a subject, style or motion consistent throughout:

```bash
python -c "
from utils.video import submit_video
print(submit_video('same character, now walking through a market', seconds=5,
                   reference_images=['character.png']))
"
```

`reference_video=` works the same way and takes a clip **2 to 30 seconds**
long. Anything longer breaks both limits at once — too long and too big — so
cut and compress in one pass. A clip carries movement and pacing that stills
cannot, so it is worth the extra step:

```bash
ffmpeg -v error -ss 0 -t 20 -i theirs.mp4 -c:v libx264 -crf 28 -preset veryfast -an ref.mp4 -y
```

That turned a 56-second 22 MB clip into 1.6 MB in two seconds. Trimming with
`-c copy` instead is quicker but keeps the original bitrate, so a 1080p source
comes out over the size limit anyway and costs you a second attempt.

**Measure the length, don't read it off the filename.** The limit is exact —
30.04 seconds is refused — and a submit the provider rejects for a bad
duration is charged anyway:

```bash
ffprobe -v error -show_entries format=duration -of csv=p=0 theirs.mp4
```

**Say what actually went into the render.** Deciding their clip would pull the
result the wrong way is a fair call — a cat reference really can push a lion
towards cat-like features. Making that call silently is not: call it "the same
style as your clip" and the user believes their file is in there when none of
it is. One line naming what you used is enough.

**Reference images must be 300 to 6000 pixels tall.** Always scale by height,
as `scale=-2:1080` above does — scaling by width instead can drop a wide frame
under the floor, which is how `scale=480:-1` once produced a 270px frame the
model refused. Two or three reference images are usually enough — every one of
them travels inside the request, and thirty is the hard limit.

Every image and clip may be a file on disk or a public URL — a file someone
sent in chat must be downloaded first.

Output orientation follows what you give it: text alone gives 1280x720
landscape, and an image or clip makes it match that instead.

**2. Poll in a loop, not one call per check.** Checking is free, so check
every 15 seconds — but do it inside a single bash call that stops as soon as
the clip is ready. One call per check burns a turn each time and runs the
budget out long before the render finishes.

```bash
for i in $(seq 1 8); do sleep 15; python -c "
from utils.video import check_video
import sys
r = check_video('PASTE_THE_ID')
print(r)
if r.get('video_url') or r.get('status') == 'failed': sys.exit(3)
"; if [ $? -eq 3 ]; then break; fi; done
```

That covers two minutes. Still rendering? Run the same block again. Keep each
block to about that length rather than one long sleep — a long one tells you
nothing until it ends, and you cannot react to a failure.

**3. Download it, then upload it to the user.**

```bash
python -c "
from utils.video import download_video
print(download_video('PASTE_THE_URL', 'balloon.mp4'))
"
```

### Handing off a video that is still rendering

**A render usually outlives the run that started it.** The monitor gets five
minutes and renders take three to twelve, so expect to hand off on any video,
not only a long one. That is the normal course of events, not a failure — but
a second submit is a second charge, and a 30-second clip runs to fourteen
dollars.

**Whoever picks it up gets the issue, not this page.** So the first line of the
issue tells them to come here, and the rest carries only what this page cannot
know:

```
Run the images-video skill before starting.

- video_id: <id>       already submitted and PAID FOR — never submit again
- length: <n> seconds
- submitted at: <HH:MM>, status was <queued | in_progress> when I wrote this
- deliver to: channel <id>, thread <ts>
- uploaded to the user as of writing this: yes / no
- files already on disk: <paths, or none>
```

The submit time matters because `check_video` does not report one: without it
the next run cannot tell a job that has been queued twenty minutes from one
submitted a moment ago, and cannot give the user an honest answer about the
wait.

**Do not retype the polling or download steps into the issue.** Copied by hand
they come out shortened, and the shortened version is what loses the file or
buys a second render. Point at the skill and let it be read.

If you are the one picking such a task up, **read the thread first**. That last
field is a snapshot: the run that wrote it may have uploaded the clip a moment
afterwards. **The thread decides, not the issue.**

- **The video is already in the thread** — the previous run finished the job.
  Close the issue and stop. Do not send it again and do not comment.
- **Not there yet** — go back to steps 2 and 3 above: poll with that loop,
  download, upload into the thread the issue names, then close. Never submit
  again; that clip is paid for and a new submit buys a different one.
- **The render failed** — say so in the thread and close the issue. Do not
  re-render unless the user asks for it.

**A failure in the first minute after a render lands is worth one retry.** The
provider goes briefly odd right as it completes — a download has come back 400,
a check has hung — and it clears within seconds. Retry once before reporting
it as broken.

**Once the file is with the user, you are done.** Close the issue and stop
there. Do not re-render it at a nicer length, do not tidy up the wording of
what was already said, do not open follow-up work nobody asked for. The user
wanted a video and now has one.

**Every attempt costs money, including one the filter refuses.** It is strict
and not always consistent, so an innocent prompt is occasionally rejected.
Reword it and try **once** more, then tell the user what happened — never retry
in a loop.

### Send the result to the user

A file on disk is not a delivered result. Upload it, and say what it is:

```bash
python messaging/slack/interface.py upload logo.png -m "Here's the logo — happy to adjust the colour"
```

### If it goes wrong

- **500 / 502 / 503** — the gateway wobbled. The image helper retries on its
  own; a video submit does not. If it still fails, wait a few seconds and try
  once more, then tell the user rather than looping.
- **Video generation failed / content flagged** — the filter refused the prompt.
  Reword it and try once more, then tell the user. Never loop: each attempt is
  charged whether or not you get a clip.
- **"cannot be combined with"** — you asked for a pinned frame and a reference
  in the same call. Pick one; the model will not take both.
- **"Media seconds must be in [2, 30] seconds range"** — the reference clip is
  too long or too short. Cut a section with ffmpeg rather than giving up on it.
- **"Reference height must meet in [300, 6000] range"** — the reference image
  is too short. Re-extract it scaling by height (`scale=-2:1080`), never by
  width.
- **"No video MCP server is registered"** — video isn't switched on in this
  environment. Retrying won't help; say so and offer an image instead.
- **Words in the image came out wrong** — put the exact text in quotes in the
  prompt and add `--quality high`.
- **An edit changed something it shouldn't** — list what to preserve in the
  prompt and repeat that list every time you iterate.
- **Close but not right** — make one small change per attempt instead of
  rewriting the whole prompt.

For image prompt structure and the techniques that most affect quality, read
`reference/IMAGE_PROMPTING.md` in this skill folder.
