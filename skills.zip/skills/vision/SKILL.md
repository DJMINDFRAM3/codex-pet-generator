---
name: vision
description: This model is blind to pictures, and the Read tool cannot help — it fails on a .png, .jpg or .mp4 and takes the whole request down with it. These tools are the only way to see one, whether it arrived in chat, sits on disk, or is a screenshot you took yourself: photos, diagrams, charts, error messages, UI designs, video footage.
---

## Vision

The helpers live in `/workspace/ninja/utils/vision.py`. They find the gateway and
its credentials themselves — nothing to configure. Run everything from
`/workspace/ninja`.

**You cannot see pictures yourself, and `Read` will not help** — it fails on a
`.png`, `.jpg` or `.mp4` and takes the whole request down with it. A file becomes
visible only through the tools below, including a screenshot you took a second
ago. Never describe a picture you have not put through one, and never say you
looked at something you did not.

For creating images and video rather than reading them, use the images-video
skill instead.

### Get the file first

**A picture or clip someone sent is not on disk yet.** The message shows you the
URL:

```
│  🖼️  [Image: chart.png (image/png, 210 KB)]
│      URL: https://files.slack.com/.../download/chart.png
```

That URL needs the chat token, so a plain fetch returns an error page rather
than the file. Downloading is free:

```bash
python -c "
from utils.vision import download_attachment
print(download_attachment('THE_URL_FROM_THE_MESSAGE', 'media/chart.png'))
"
```

**Never guess a path.** If you did not download the file in this run, you do not
have it — a file that happens to be on disk is somebody else's, and describing
it as though it were theirs is worse than saying you cannot see it. No URL in
the message means nothing arrived: say so and ask them to resend.

A path on disk or a public URL both work once you have one. Every call is
charged, so read a file once and work from the answer rather than calling again
with a reworded prompt.

**Every tool answers in headed markdown sections**, listed under each below.
That is for you to work from — relay what the user asked about in your own
words. Pasting the whole thing back is a wall of text they did not ask for.

### Pick the tool that matches the task

Each tool carries its own instructions, and those are what make the answer
useful. Reaching for `analyze_image` when a specialised tool fits gives a
noticeably worse result.

Two tools often look like they both fit. They do not — pick by what you want
out of it, not by what the picture is of.

| You want | Tool | Not |
|---|---|---|
| The text itself, transcribed | `extract_text_from_screenshot` | `analyze_image` |
| To know what broke and why | `diagnose_error_screenshot` | `extract_text_from_screenshot`, even when the error is in a code screenshot |
| Boxes and arrows explained | `understand_technical_diagram` | `analyze_data_visualization` |
| The numbers read off | `analyze_data_visualization` | `understand_technical_diagram`; a dashboard is a chart, not a UI |
| A design turned into code, a spec or prose | `ui_to_artifact` | `extract_text_from_screenshot` |
| A design checked against what was built | `ui_diff_check` | anything else — it is only for design-versus-build. To compare two unrelated images, call `analyze_image` on each |
| What happens in a clip | `analyze_video` | the audio skill — unless the point is what is said, since these frames carry no sound |
| Anything else | `analyze_image` | — |

### Read the text in a screenshot

Code, terminal output, logs, documentation — transcribed with the indentation
and structure intact, so extracted code is runnable as-is.

```bash
python -c "
from utils.vision import extract_text_from_screenshot
print(extract_text_from_screenshot('media/shot.png', 'This is Python'))
"
```

Naming the language when you can tell improves accuracy — the model uses it to
sanity-check ambiguous characters like `l` against `1`, or `O` against `0`.

*Extracted Text · Content Type · Language/Format · OCR Corrections · Quality
Notes* — the corrections section lists every character it had to judge, which is
worth checking before you run extracted code.

### Work out an error

Stack traces, exception dialogs, failing test output. Says what broke and what
to do about it.

```bash
python -c "
from utils.vision import diagnose_error_screenshot
print(diagnose_error_screenshot('media/err.png', 'This is from our CI run'))
"
```

The second argument is optional everywhere, but context helps — what was being
attempted, what changed recently.

*Error Summary · Root Cause Analysis · Solution · Prevention · Additional Notes*

### Explain a diagram

Architecture, flowcharts, UML, ER, system design.

```bash
python -c "
from utils.vision import understand_technical_diagram
print(understand_technical_diagram('media/arch.png'))
"
```

*Diagram Overview · Components · Relationships & Data Flow · Architecture
Analysis · Textual Representation* — that last section rewrites the diagram as
text, which is what you want if you are going to reason about it further.

### Read a chart

Graphs, dashboards, anything where the point is the numbers.

```bash
python -c "
from utils.vision import analyze_data_visualization
print(analyze_data_visualization('media/chart.png', 'Which bar is highest, and by how much?'))
"
```

*Visualization Summary · Key Metrics · Trends & Patterns · Anomalies & Insights ·
Actionable Recommendations*

### Turn a UI design into something

Four different outputs, and they are genuinely different — pick deliberately.

```bash
python -c "
from utils.vision import ui_to_artifact
print(ui_to_artifact('media/mockup.png', 'code', 'React with Tailwind, mobile first'))
"
```

| `output_type` | You get |
|---|---|
| `code` | Frontend code for the design |
| `prompt` | A prompt that would recreate this UI |
| `spec` | A design specification — spacing, type, colour |
| `description` | Prose describing the interface |

`code` answers with *Generated Code · Structure Explanation · Styling Notes ·
Assumptions and Observations · Usage Instructions* — read the assumptions before
shipping it, that is where it tells you what it had to guess.

### Compare a design against the build

```bash
python -c "
from utils.vision import ui_diff_check
print(ui_diff_check('media/design.png', 'media/built.png', 'Focus on spacing and type scale'))
"
```

**Reference first, implementation second.** The order is what tells the model
which one is meant to be correct; swapping them inverts every finding.

*Overall Assessment · Detailed Differences · Layout / Content / Styling Issues ·
Recommended Fixes · Testing Notes* — differences come back ordered by severity,
so lead with the first ones.

### Anything else

```bash
python -c "
from utils.vision import analyze_image
print(analyze_image('media/photo.jpg', 'How many people are wearing hats?'))
"
```

*Main Response · Detailed Observations · Context & Analysis · Additional Notes*
— it answers the question first, so the opening lines are usually all you need.

### Watch a video

```bash
python -c "
from utils.vision import analyze_video
print(analyze_video('media/clip.mp4', 'What happens, and in what order?'))
"
```

**ffmpeg has to be installed** — the helper samples the clip into frames at up
to one per second, 360p, because the provider takes video only as a URL it can
fetch itself and will not read bytes you send it:

```bash
apt-get update -qq && apt-get install -y -qq ffmpeg   # ~30s, not preinstalled
```

You do not do the sampling; passing the path is enough. **30 frames is the
whole budget, spread across the clip** — a minute is read every two seconds, five
minutes every ten. Nothing is cut off, but action between frames is missed, so
say how coarsely you looked. When you know which part matters, cut it first and
you get a frame a second:

```bash
ffmpeg -v error -ss 90 -t 30 -i theirs.mov -c copy clip.mp4 -y
```

A public URL is passed straight through instead — but it must be fetchable
without an auth header and without redirects, which a chat link is not. Download
those and pass the path.

The frames carry no sound. For a clip whose point is speech, transcribe it with
the audio skill instead.

### Formats and limits

| | Accepted | Limit |
|---|---|---|
| Images | `.jpg` `.jpeg` `.png` | 5 MB each |
| Video | `.mp4` `.mov` `.m4v` | 30 frames, however long the clip |

The file is read and sent inline from here, so a path only ever means a path on
**this** machine — and a file over the limit is refused before anything leaves,
so it costs nothing. You still have to fix it before you get an answer:

```bash
ffmpeg -v error -i big.png -vf scale=-1:1080 small.png -y     # shrink an image
ffmpeg -v error -i shot.webp shot.png -y                       # convert a format
```

### Send the answer to the user

These tools return text, not files. Reply with what you found in your own words
— do not paste a wall of tool output. If they asked for something concrete, like
code from a mockup, put that in a file and upload it:

```bash
python messaging/slack/interface.py upload Login.tsx -m "Built from your mockup" -t <thread_ts>
```

### If it goes wrong

- **"Image file not found"** — you passed a path you never created. Download the
  file from the URL in the message first.
- **"Got a web page, not a file"** — the chat token is stale. Say so rather than
  retrying; it will not fix itself.
- **"Unsupported image format"** — only jpg and png are read. Convert it.
- **"is N MB; the limit is 5 MB"** — shrink it with the commands above.
- **"ran out of room before answering"** — the answer was cut off. Ask for less:
  one region of the image, or a shorter form.
- **"No vision MCP server is registered"** — vision is not switched on in this
  environment. Retrying will not help; say so and work without it.
- **The answer describes something that is not in the picture** — you are
  probably looking at the wrong file. Check the path you passed came from a
  download in this run.
