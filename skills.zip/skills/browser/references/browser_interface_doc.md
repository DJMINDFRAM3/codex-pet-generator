```python
from browser_interface import BrowserInterface

# ✅ CORRECT: Connect to the persistent browser (tabs survive between tasks)
browser = BrowserInterface.connect_cdp()

# ❌ WRONG: Don't create a new browser — it won't persist
# browser = BrowserInterface(...)
# browser.start()

# Navigation
browser.goto("https://example.com", wait_until="load")
browser.reload()
browser.go_back()
browser.go_forward()

# Page properties
browser.title       # Page title
browser.url         # Current URL
browser.content     # Full page HTML

# Interaction
browser.click("selector")
browser.fill("selector", "value")
browser.type_text("selector", "text", delay=50)
browser.press("selector", "Enter")
browser.select_option("selector", value="option1")
browser.check("selector")
browser.hover("selector")

# Content extraction
browser.text("selector")              # Visible text
browser.html("selector")              # Inner HTML
browser.attribute("selector", "href") # Get attribute
browser.query_all("selector")         # Count matching elements
browser.evaluate("javascript code")   # Run arbitrary JS

# Screenshots & PDF
browser.screenshot("path.png")
browser.screenshot("path.png", full_page=True)
browser.pdf("path.pdf")

# Scrolling
browser.scroll_down(px=500)
browser.scroll_up(px=500)
browser.scroll_to("selector")
browser.scroll_to_top()
browser.scroll_to_bottom()

# Waiting
browser.wait_for("selector", timeout=10000)
browser.wait_for_url("**/results")
browser.sleep(2)

# Cookies
browser.cookies()
browser.clear_cookies()

# Disconnect when done (browser keeps running, tabs preserved)
browser.stop()
```