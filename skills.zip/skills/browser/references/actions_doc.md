```python
from browser.actions import execute_action, set_elements, clear_selector_cache

# IMPORTANT: Pass elements from observer before executing actions
set_elements(observation["interactive_elements"])

# Execute any action — returns a result string
result = execute_action(browser, "click", {"selector": "#submit"})
result = execute_action(browser, "fill", {"selector": "#search", "value": "AI news"})
result = execute_action(browser, "goto", {"url": "https://google.com"})
result = execute_action(browser, "scroll_down", {"px": 500})
result = execute_action(browser, "extract_text", {"selector": "body"})
result = execute_action(browser, "screenshot", {"filename": "current.png"})
result = execute_action(browser, "dismiss_overlay", {})
result = execute_action(browser, "press", {"key": "Enter"})
result = execute_action(browser, "wait", {"seconds": 2})
```