---
name: browser-automation
description: Create a browser with UI the agent can manage
---

# Browser Automation

## Python API — Import and Use Directly

Everything below lives in the `browser` package and imports from the repo root (`/workspace/ninja`). Here's your toolkit:

### 1. Browser Interface (`browser/browser_interface.py`)

The low-level browser driver. **Always connect to the persistent browser — never launch a new one.**
Check `references/browser_interface_doc.md` inside the tool folder for code references.

> **⚠️ IMPORTANT:** `browser.stop()` only disconnects — it does NOT close the browser.
> Tabs, cookies, and state persist for the next task. This is by design.

### 2. Observer (`browser/observer.py`)

Captures the full page state in one call. This is your **eyes**.

```python
from browser.observer import observe

# Takes a snapshot of the current page
observation = observe(browser, step=0, screenshot=True)

# Returns:
# {
#     "url": "https://example.com",
#     "title": "Example Page",
#     "screenshot_path": "browser/screenshots/step_000.png",
#     "screenshot_b64": "base64...",          # For vision analysis
#     "accessibility_tree": "...",             # Compact page structure
#     "interactive_elements": [...],           # Clickable/fillable elements
#     "has_overlay": True/False,               # Cookie banner/popup detected
#     "errors": "..." or None,                 # JS/network errors
# }
```

**What the observer does:**

- Waits for page to settle (domcontentloaded + networkidle)
- Extracts all interactive elements (buttons, links, inputs, etc.) with multiple selector candidates
- Injects **Set-of-Mark (SoM) labels** — numbered red badges on each element
- Takes a screenshot (with badges visible)
- Removes the badges
- Builds the accessibility tree (compact structured page representation)
- Detects overlays (cookie banners, modals, popups)
- Captures any JS/network errors

**Interactive elements** look like:

```python
{
    "index": 0,
    "tag": "input",
    "type": "text",
    "text": "",
    "placeholder": "Search...",
    "id": "search",
    "selector": "#search",
    "selectors": ["#search", "input[name='q']", "input[type='text']"],
    "visible": True,
}
```

### 3. Actions (`browser/actions.py`)

Executes browser actions with **self-healing selectors**.
Check `references/actions_doc.md` inside the tool folder for code references.

**Self-healing:** If a selector fails, the action module automatically tries alternative selectors from the elements list. It also caches successful fallbacks per page.

**Full action list:**

| Action              | Params                       | Description                        |
| ------------------- | ---------------------------- | ---------------------------------- |
| `goto`              | `url`                        | Navigate to URL                    |
| `click`             | `selector`                   | Click element (with self-healing)  |
| `fill`              | `selector`, `value`          | Clear + type into input            |
| `type_text`         | `selector`, `text`, `delay`  | Type character by character        |
| `press`             | `key`, `selector` (optional) | Press keyboard key                 |
| `select_option`     | `selector`, `value`/`label`  | Select dropdown option             |
| `check`             | `selector`                   | Check checkbox                     |
| `hover`             | `selector`                   | Hover over element                 |
| `dismiss_overlay`   | —                            | Auto-dismiss cookie banners/popups |
| `go_back`           | —                            | Browser back                       |
| `go_forward`        | —                            | Browser forward                    |
| `reload`            | —                            | Reload page                        |
| `scroll_down`       | `px` (default 500)           | Scroll down                        |
| `scroll_up`         | `px` (default 500)           | Scroll up                          |
| `scroll_to`         | `selector`                   | Scroll element into view           |
| `scroll_to_top`     | —                            | Scroll to top                      |
| `scroll_to_bottom`  | —                            | Scroll to bottom                   |
| `extract_text`      | `selector`                   | Get text content (max 2000 chars)  |
| `extract_html`      | `selector`                   | Get HTML (max 2000 chars)          |
| `extract_attribute` | `selector`, `attribute`      | Get element attribute              |
| `extract_table`     | `selector`                   | Extract table as rows              |
| `extract_links`     | `selector`                   | Extract all links (text + URL)     |
| `wait`              | `seconds`                    | Wait                               |
| `wait_for_element`  | `selector`, `timeout`        | Wait for element to appear         |
| `screenshot`        | `filename`                   | Save screenshot                    |
| `save_pdf`          | `filename`                   | Save page as PDF                   |
| `execute_js`        | `script`                     | Run JavaScript                     |
| `get_cookies`       | —                            | List cookies                       |
| `clear_cookies`     | —                            | Clear cookies                      |

### 4. Presets (`browser/presets.py`)

Pre-built task templates for common operations:

```python
from browser.presets import get_preset_task, list_presets

# Get a pre-built task string
task = get_preset_task("screenshot", url="https://example.com")
task = get_preset_task("search", query="AI news 2026")
task = get_preset_task("extract", url="https://example.com")

# Available presets: screenshot, extract, extract_links, search, fill_form, pdf, monitor
print(list_presets())
```

### 5. VNC (`browser/vnc.py`)

Share the live browser view with humans:

```python
from browser.vnc import get_vnc_url, share_vnc_link, request_human_help

# Get the public noVNC URL (port 6081, no password, auto-connect)
url = get_vnc_url()  # https://6080-<sandbox_id>.app.super.<stage>myninja.ai/vnc.html?autoconnect=true

# Post VNC link to {{CHANNEL_NAME}}
share_vnc_link("Starting browser automation task")

# Request human help (CAPTCHA, login, etc.)
request_human_help("CAPTCHA detected", page_url="https://example.com/login")
```

### 6. Config (`browser/config.py`)

```python
from browser.config import NinjaConfig, SCREENSHOTS_DIR, BROWSER_DATA_DIR

config = NinjaConfig.load()
# config.model, config.max_steps, config.headless, config.viewport_width, etc.
```

---

## Selector Best Practices

When choosing selectors for actions, use this priority (most reliable first):

1. **`#id`** — most stable: `#search-input`
2. **`[aria-label]`** — accessibility: `input[aria-label="Search"]`
3. **`[name]`** — form fields: `input[name="q"]`
4. **`text=`** — visible text: `text=Submit`
5. **CSS class** — less stable: `button.primary`
6. **`[index]`** — SoM reference: `[0]`, `[3]` (resolved from interactive elements)

**SoM index selectors** (`[0]`, `[1]`, etc.) reference elements from the observer's interactive elements list. The actions module resolves them automatically.

---

## Standard Task Workflow

Here's the pattern for executing any browser task:

```python
from browser.browser_interface import BrowserInterface
from browser.observer import observe
from browser.actions import execute_action, set_elements, clear_selector_cache
from browser.config import NinjaConfig

# 1. Connect to persistent browser (already running via browser_server.py)
browser = BrowserInterface.connect_cdp()

# 2. Navigate to starting URL
browser.goto("https://example.com", wait_until="load")

# 3. Observe-Think-Act loop
config = NinjaConfig.load()
for step in range(config.max_steps):
    # OBSERVE
    obs = observe(browser, step=step, screenshot=True)
    set_elements(obs["interactive_elements"])

    # THINK (this is YOU — analyze the observation and decide)
    # Look at: obs["url"], obs["title"], obs["accessibility_tree"],
    #          obs["interactive_elements"], obs["has_overlay"], obs["errors"]
    # Also look at the screenshot: obs["screenshot_path"]

    # ACT
    if obs["has_overlay"]:
        execute_action(browser, "dismiss_overlay", {})
        continue

    # ... your logic here ...
    result = execute_action(browser, "click", {"selector": "#some-button"})

    # Check result
    if result.startswith("ERROR:"):
        # Handle error — try different approach
        pass

# 4. Disconnect (browser stays alive — tabs and state persist for next task)
browser.stop()
```

> **NOTE:** Never call `BrowserInterface(...)` + `browser.start()` for Ninja tasks.
> Always use `BrowserInterface.connect_cdp()` to connect to the persistent browser.
> The browser server is managed separately via `browser/browser_server.py`.

---

## Error Handling

### Self-Healing Selectors

If a selector fails, the actions module automatically tries alternatives. You don't need to handle this manually — just use the best selector you can find and the system will try fallbacks.

### Overlay Detection

If `obs["has_overlay"]` is True, always dismiss it first:

```python
execute_action(browser, "dismiss_overlay", {})
```

### Consecutive Errors

If you get 3+ consecutive `ERROR:` results, try:

1. `clear_selector_cache()` — reset cached selectors
2. `execute_action(browser, "reload", {})` — reload the page
3. Try a completely different approach

### Loop Detection

Watch for yourself repeating the same action. If you've tried the same thing 3 times, change strategy.

### Human Intervention

If you hit a CAPTCHA, login wall, or anything you can't automate:

```python
from browser.vnc import request_human_help
request_human_help("CAPTCHA detected", page_url=browser.url)
# Then wait or report back
```

---

## Persistent Browser Server

The browser runs as a **persistent background process** managed by `browser/browser_server.py`.
It survives across Claude Code sessions — tabs, cookies, and state are preserved between tasks.

```bash
# Check if browser is running
python browser/browser_server.py status

# Start browser (if not running)
python browser/browser_server.py start

# Restart browser (kills and relaunches)
python browser/browser_server.py restart

# Stop browser
python browser/browser_server.py stop
```

The browser server should already be running when you start a task. If `connect_cdp()` fails
with a `ConnectionError`, start the server first:

```python
from browser.browser_server import ensure_running
ensure_running()  # Starts browser if not already running
```

## VNC: Live Browser Sharing

The browser runs on a virtual display visible via VNC at port 6080 (no password, no nginx). Share the link when:

- Starting a task (so humans can watch)
- Hitting a blocker (CAPTCHA, login)
- Demonstrating results

```python
from browser.vnc import get_vnc_url
vnc_url = get_vnc_url()
```

The persistent browser is always in **headed mode** and visible on VNC.


**Need help:**
```bash
# Or use the request_human_help() helper which includes the VNC link automatically
python -c "from phantom.vnc import request_human_help; request_human_help('Hit a CAPTCHA on google.com/login', 'https://google.com/login')"
```

## Stealth (`phantom/stealth.py`)

Anti-bot detection evasion. **Applied automatically** on every `connect_cdp()`, `start()`, and `new_tab()` — no manual setup needed.

```python
from browser.browser_interface import BrowserInterface

# Stealth is auto-applied when connecting:
browser = BrowserInterface.connect_cdp()  # stealth already active!

# Check stealth status:
result = browser.check_stealth()
# Returns: {"webdriverType": "undefined", "chromeRuntime": true, "plugins": 3, ...}
```

**CLI:**
```bash
python phantom/stealth.py check   # Verify stealth is active
```

**What it patches:**
- `navigator.webdriver` → `undefined` (Google's primary check)
- `chrome.runtime` → present (looks like normal Chrome)
- `navigator.plugins` → 3 entries (not empty like automated browsers)
- `navigator.languages` → `['en-US', 'en']`
- WebGL vendor/renderer → realistic NVIDIA values
- Removes CDP/ChromeDriver artifacts

## Session Health (`phantom/session_health.py`)

Monitor browser login sessions for **any** service. **Accessible directly from BrowserInterface.**

Supported services: `google`, `linkedin`, `twitter`, `github`, `amazon`, `facebook`.

```python
from browser.browser_interface import BrowserInterface

browser = BrowserInterface.connect_cdp()

# Check a specific service
result = browser.check_session("google")
# result["valid"] → True/False
# result["cookies_found"] → ["SID", "HSID", ...]

result = browser.check_session("linkedin")
result = browser.check_session("twitter")

# Check all services at once
all_results = browser.session_status()
# {"google": {...}, "linkedin": {...}, "twitter": {...}, ...}

# Get VNC URL for manual login
url = browser.vnc_url()
```

**Need help:**

```bash
# Or use the request_human_help() helper which includes the VNC link automatically
python -c "from browser.vnc import request_human_help; request_human_help('Hit a CAPTCHA on google.com/login', 'https://google.com/login')"
```

### 7. Stealth (`browser/stealth.py`)

Anti-bot detection evasion. **Applied automatically** on every `connect_cdp()`, `start()`, and `new_tab()` — no manual setup needed.

```python
from browser.browser_interface import BrowserInterface

# Stealth is auto-applied when connecting:
browser = BrowserInterface.connect_cdp()  # stealth already active!

# Check stealth status:
result = browser.check_stealth()
# Returns: {"webdriverType": "undefined", "chromeRuntime": true, "plugins": 3, ...}
```

**CLI:**

```bash
python browser/stealth.py check   # Verify stealth is active
```

**What it patches:**

- `navigator.webdriver` → `undefined` (Google's primary check)
- `chrome.runtime` → present (looks like normal Chrome)
- `navigator.plugins` → 3 entries (not empty like automated browsers)
- `navigator.languages` → `['en-US', 'en']`
- WebGL vendor/renderer → realistic NVIDIA values
- Removes CDP/ChromeDriver artifacts

**Login Flow (any service):**

1. Run `python browser/session_health.py status` to see which services need login
2. Open VNC: `python browser/session_health.py login-url`
3. Navigate to the service login page in the virtual browser
4. Log in manually — cookies persist in `browser_data/`
5. Use `monitor` for continuous health checking

---

## File Locations

| Path                        | Purpose                                                                |
| --------------------------- | ---------------------------------------------------------------------- |
| `browser/browser_server.py` | Persistent browser process manager (start/stop/status)                 |
| `browser/screenshots/`      | Step-by-step screenshots (step_000.png, step_001.png, ...)             |
| `browser/browser_data/`     | Persistent browser state (cookies, cache, selectors)                   |
| `browser/config.py`         | Configuration (model, viewport, timeouts)                              |
| `browser/observer.py`       | Page observation (screenshot + a11y tree + elements)                   |
| `browser/actions.py`        | Action execution with self-healing selectors                           |
| `browser/presets.py`        | Pre-built task templates                                               |
| `browser/vnc.py`            | VNC URL generation and human help requests                             |
| `browser/stealth.py`        | Anti-bot stealth JS + check (auto-applied via BrowserInterface)        |
| `browser/session_health.py` | Multi-service session health checker (Google, LinkedIn, Twitter, etc.) |
| `browser/browser_interface.py` | Low-level Playwright browser wrapper (connect_cdp / start)             |
