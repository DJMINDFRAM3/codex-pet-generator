---
name: audio
description: Turn text into spoken audio in one voice or as a multi-voice conversation, compose music, make sound effects, clean up or re-voice a recording someone sent, dub a recording or video into another language, and transcribe recordings to text, through the model gateway. Use when the user wants something read out loud, a voice message, a scripted dialogue or interview, a piece of music or a backing track, a sound effect, background noise removed from a recording, a recording said in a different voice or another language, or a transcript.
---

## Audio

The helpers live in `/workspace/ninja/utils/`. They find the gateway and its
credentials themselves — nothing to configure. Run everything from
`/workspace/ninja`.

Generating audio costs money on every call. Get the request right the first
time rather than producing variations to choose from. **Dubbing is far and away
the most expensive — several dollars a minute — and must be agreed with the user
before you start one.** Music is the next dearest; check its table before asking
for anything long.

### Find a voice

Speech and dialogue take a `voice_id`. Look one up rather than inventing one —
an invented id is a failed call you still pay for. Listing is free.

```bash
python -c "
from utils.audio import list_voices
for v in list_voices(search='british'): print(v['voice_id'], v['name'])
"
```

`search` matches the name, description and labels, so `'narration'`,
`'american'` or `'calm'` all work. Leave it out to see what is there. Omit
`voice_id` when you call for speech and you get a neutral default, which is
usually what someone wants for a summary read aloud.

**There are about twenty voices and they are all ordinary human ones** — mostly
American, a few British, one Australian, and only two labelled for character
work. There is no monster, robot, child or cartoon voice, and no way to make
one. So if someone asks for a voice the library does not have, **say that and
offer the closest match — do not quietly substitute one and present it as what
they asked for.** A search that returns nothing usually means the word does not
appear in any label, not that you should keep guessing synonyms; drop the search
and look at the whole list instead.

### Turn text into speech

```bash
python -c "
from utils.audio import text_to_speech
print(text_to_speech('Good morning — here is your daily summary.', 'brief.mp3'))
"
```

Pass `voice_id=` to choose a speaker. Output is always MP3.

Where the words come from:

- **The user gave you the text** — pass it straight through. Past a few
  sentences, read it from a file rather than fighting the shell over quotes,
  apostrophes and newlines.
- **The text is in a file they sent** — `.txt` and `.md` can be read directly.
  For a PDF, use the pdf skill to extract the text first.
- **There is no text yet** — write it yourself and show it to the user before
  you generate the audio. Fixing a wrong script costs one message; regenerating
  the audio costs money and a wait.

**One call holds 2,000 characters**, a bit under two minutes of speech, and
takes about a minute to generate. Longer text is split across several calls —
break it at paragraph or chapter boundaries, never mid-sentence, and number the
output files. Send each part as it finishes instead of making the user wait for
all of them. Before you start on anything book-sized, say how many parts it will
be and let them decide; each part costs money.

Speaks 70+ languages and picks the language up from the text itself, so there is
no setting to change. Most voices are English-trained, so other languages come
out with a slight English accent — say so if the user cares, rather than
pretending it will sound native.

### Make a two-voice conversation

For an interview, a skit, or a podcast-style exchange — one audio file, a
different voice per turn.

```bash
python -c "
from utils.audio import create_dialogue
print(create_dialogue([
  {'text': 'So how did the review land?', 'voice_id': 'VOICE_A'},
  {'text': '[laughs] Better than I expected.', 'voice_id': 'VOICE_B'},
], 'chat.mp3'))
"
```

Every turn needs its own `voice_id`, so call `list_voices` first. At most **10
different voices** and **2,000 characters across all turns**.

Square brackets steer the delivery — `[laughs]`, `[whispering]`, `[sighs]`.
They count towards the character limit and towards the cost, so use them where
they change the read, not on every line. For a single speaker use
`text_to_speech`; it is the same price and simpler.

### Compose music

An actual piece of music — a backing track, a theme, something under a
voiceover. For a single noise use a sound effect instead.

```bash
python -c "
from utils.audio import compose_music
print(compose_music('gentle lo-fi piano, slow, warm, no drums', 'backing.mp3', seconds=30, instrumental=True))
"
```

**The dearest thing here after dubbing, and the price runs with the length:**

| length | cost |
|---|---|
| 10 seconds | $0.12 |
| 30 seconds | $0.35 |
| 1 minute | $0.70 |
| 2 minutes | $1.40 |
| 10 minutes (the maximum) | **$7.00** |

So **ask how long they want it** unless they already said, and don't reach for
minutes when seconds will do — a loop under a voiceover rarely needs more than
thirty seconds. Leave `seconds` out and the composer picks a length, which is
billed as thirty seconds whatever it produces.

`instrumental=True` keeps it wordless; otherwise it may sing. Describe mood,
instruments, tempo and what the music is for — "gentle lo-fi piano, slow, warm,
no drums, under a calm voiceover" gives you something usable where "nice music"
does not.

### Make a sound effect

A short noise — a door slam, rain on a window, a sci-fi whoosh. Not speech, and
not music.

```bash
python -c "
from utils.audio import create_sound_effect
print(create_sound_effect('a heavy wooden door slamming shut in a stone hallway', 'door.mp3', seconds=3))
"
```

`seconds` is **0.5 to 30**. Leave it out and the length is chosen to suit the
description — but it is still billed as five seconds, so pass a number whenever
you know one.

Describe the sound rather than the object: "rain on a tin roof, steady, with
distant thunder" gives you something usable where "rain" does not. Don't
generate several and pick — get the description right first, and only try again
if the user asks.

### Work on a recording someone sent

The three tools below — cleaning up, re-voicing and dubbing — take a **file on
disk**, not a URL. A voice message or audio file in chat arrives as a download
link that needs the chat token, so save it first; a plain fetch gets an error
page instead of audio.

```bash
python -c "
from utils.audio import download_audio
print(download_audio('THE_DOWNLOAD_URL', 'recording.mp3'))
"
```

Downloading is free. **Everything after it is priced by how long the recording
runs**, so a long file is worth trimming before you spend on it. Cleaning up and
re-voicing cost about **$0.44 a minute** and take at most **20 MB and 15
minutes** per call; dubbing is in another league and has its own section below.

There is no audio editor installed, but the sandbox has apt and network — so
`apt-get install -y ffmpeg` is available when cutting a clip down is genuinely
worth the couple of minutes it takes. For a recording that is only a little too
long, ask which part they actually want instead.

### Clean up a recording

Strips background noise and music, leaving the voice.

```bash
python -c "
from utils.audio import isolate_audio
print(isolate_audio('recording.mp3', 'clean.mp3'))
"
```

Needs at least **5 seconds** of audio — shorter is refused, and refused after
being charged, so don't try it on a two-second clip.

### Say a recording in a different voice

Keeps the original delivery and timing, changes who it sounds like.

```bash
python -c "
from utils.audio import voice_changer
print(voice_changer('recording.mp3', 'VOICE_ID', 'changed.mp3'))
"
```

Call `list_voices` for the `voice_id`. Pass `remove_background_noise=True` to
clean the input on the way through, which saves a separate `isolate_audio` call.

### Dub a recording into another language

Re-speaks a recording or video in another language, keeping each speaker's own
voice. Works on video too — the audio track is what gets dubbed.

**Ask before you start.** This costs **about $6 a minute** — roughly thirteen
times anything else here, and a five-minute video is thirty dollars. The helper
refuses the first call and tells you the exact price of that file; quote that
figure, wait for a yes, then call again with `confirmed=True`. Do not decide on
their behalf that it is worth it.

**1. Start it, once they have agreed.** Keep both ids.

```bash
python -c "
from utils.audio import create_dubbing
print(create_dubbing('clip.mp4', 'es', source_language='en', confirmed=True))
"
```

`target_language` is a tag like `es`, `fr`, `pt-BR`. Leave `source_language` out
to auto-detect.

**2. Check every 30 seconds.** Checking is free. **Dubbing takes about as long
as the recording itself** — a five-minute video needs five minutes — so tell
them roughly how long it will be and don't treat the wait as a failure.

```bash
sleep 30 && python -c "
from utils.audio import check_dubbing
print(check_dubbing('PROJECT_ID', 'LANGUAGE_ID'))
"
```

**3. Download as soon as it says `completed`.** The link is signed and **expires
an hour after you get it** — if it has gone stale, call `check_dubbing` again
for a fresh one rather than re-dubbing.

```bash
python -c "
from utils.audio import download_dubbing
print(download_dubbing('THE_AUDIO_URL', 'dubbed.flac'))
"
```

**Upload it the moment it lands, before doing anything else to it.** The dub is
already paid for, and a run that stops halfway through tidying it up leaves the
user with nothing to show for the money. Send the file, then offer to improve it.

**The result is FLAC, not MP3**, and about five times the size. If they want
something smaller, `which ffmpeg || apt-get install -y ffmpeg` and convert —
check first, it is often already installed, and the install alone can eat a
whole turn. Never re-dub in another format; that charges again.

**4. Optionally, the transcript.** Free, and available once the job is done.
Without a `language_id` you get the original wording with timings and speakers;
with one you also get the translation, which is handy for subtitles or for
showing what was said.

```bash
python -c "
from utils.audio import get_dubbing_transcript
for s in get_dubbing_transcript('PROJECT_ID', 'LANGUAGE_ID'):
    print(s['start_s'], s['speaker_id'], s.get('translation'))
"
```

If your run is cut short, the ids still work later — the job is already paid
for. Whatever you hand to the next run, put the **project_id and language_id**
in it: starting again is a second charge at several dollars a minute.

### Transcribe audio to text

Transcription is the one case where you do **not** download first: use the
transcribe command from your system prompt and give it the URL, and it fetches
the file itself and prints the transcript.

The transcript is text like any other: summarise it, answer from it, or act on
it. Only send the raw transcript back if that's what was asked for.

### Send the result to the user

A file on disk is not a delivered result — and once you have paid for one,
**upload it before you do anything else with it**. Converting, trimming or
tidying can all fail or run out of turn; the money is already spent either way,
so get the file to the user first and refine it afterwards.

Upload it, and say what it is:

```bash
python messaging/slack/interface.py upload brief.mp3 -m "Here's the summary as a voice note"
```

### If it goes wrong

- **500 / 502 / 503** — the gateway wobbled. Nothing here retries on its own,
  because a repeat is a second charge. Wait a few seconds and try once more,
  then tell the user rather than looping.
- **"No audio MCP server is registered"** — audio isn't switched on in this
  environment. Retrying won't help; say so.
- **A voice_id was rejected** — you invented it. Call `list_voices` and use an
  id from the result.
- **The effect isn't what you pictured** — describe the sound and its setting,
  not the object making it, and change one thing per attempt.
- **The speech is in the wrong language** — the language comes from the text
  itself, so check the script rather than looking for a setting.
- **It is taking a while** — a full-length request runs about a minute, and a
  recording you upload takes longer still. Dubbing takes as long as the
  recording. That is normal, not a failure; don't start a second one.
- **"will cost about $X … call again with confirmed=True"** — this is not an
  error. Tell the user the figure, wait for a yes, then repeat the call with
  `confirmed=True`.
- **A dub download 404s or 403s** — the signed link expired. Call
  `check_dubbing` again for a fresh one; never re-dub, that charges again.
- **"Audio duration is … below the minimum"** — the clip is under 4.6 seconds.
  Isolation cannot run on it; say so rather than retrying.
- **"Could not read the length of …"** — the file isn't audio, or the download
  saved an error page. Check what `download_audio` actually wrote.
